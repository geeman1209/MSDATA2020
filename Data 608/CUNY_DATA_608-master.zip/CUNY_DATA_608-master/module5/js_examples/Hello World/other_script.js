function myScript(){
    return('you can also import other scripts!');
}